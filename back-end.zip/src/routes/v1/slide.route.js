/* eslint-disable prettier/prettier */
const express = require('express');
const upload = require('../../middlewares/storage');
const { Slide } = require('../../models');

const router = express.Router();

router.route('/').get(async (req, res) => {
    const data = await Slide.find().lean();
    res.send(data);
}).post(upload.any('images'), (req, res) => {
    Slide.deleteMany();
    const images = []
    req.files.forEach((img) => {
        images.push(img.filename)
    })
    Slide.create({ images });
    res.send(images)
});

module.exports = router;
