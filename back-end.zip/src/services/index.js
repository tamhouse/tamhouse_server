module.exports.categoryService = require('./category.service');
module.exports.productService = require('./product.service');
module.exports.inforService = require('./infor.service');
