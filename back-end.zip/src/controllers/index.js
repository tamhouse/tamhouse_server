module.exports.categoryController = require('./category.controller');
module.exports.productController = require('./product.controller');
module.exports.inforController = require('./infor.controller');
