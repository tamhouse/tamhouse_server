module.exports.Category = require('./category.model');
module.exports.Product = require('./product.model');
module.exports.Infor = require('./infor.model');
module.exports.Slide = require('./slide.model');
